﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SeatBookingSimulator.Classes
{
    class Global
    {
    }
}
